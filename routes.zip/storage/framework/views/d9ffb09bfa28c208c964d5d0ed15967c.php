<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah Data Skill</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-my-image font-poppins text-white">
    <div class="container border border-gray-600 rounded-xl bg-transparent backdrop-blur-lg my-5">
        <div class="row mt-3">
            <div class="col-md-6">
                    <div class="">
                        <form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
                        
                            <?php echo csrf_field(); ?>

                            <div class="border border-gray-600 rounded-lg p-3">
                                <label class="">NAMA</label>
                                <input type="text" class="w-full bg-gray-800 px-2 py-1 rounded-lg <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Masukkan nama Skill">
                            
                                <!-- error message untuk title -->
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="border border-gray-600 rounded-lg p-3 mt-3">
                                <label class="font-weight-bold">GAMBAR</label>
                                <input type="file" class="w-full bg-gray-800 px-2 py-1 rounded-lg <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image">
                            
                                <!-- error message untuk title -->
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="border-4 border-str-btn rounded-xl bg-lime-600 my-6 py-3 px-8 text-white font-poppins transform transition hover:scale-105 duration-300 ease-in-out">SIMPAN</button>
                            <button type="reset" class="border-4 border-str-btn rounded-xl bg-orange-600 my-6 py-3 px-8 text-white font-poppins transform transition hover:scale-105 duration-300 ease-in-out">RESET</button>

                        </form> 
                    </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\laragon\www\crud-portolk\resources\views/posts/create.blade.php ENDPATH**/ ?>