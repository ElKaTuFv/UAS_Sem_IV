<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Post Skill</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Itim&family=Jura&family=Poppins&display=swap" rel="stylesheet">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
</head>
<body class="bg-my-image">


<section>
    <nav class="bg-transparent backdrop-blur-3xl border-b-black md:flex md:items-center md:justify-between w-full fixed xl:px-[300px] z-10">
        <div class="flex justify-between items-center">
            <a href="#home" class="flex text-center ">
                <div class="flex items-center border-r-4 pr-5">
                    <h1 class="font-itim text-white text-[40px]">Lk-</h1>
                    <h1 class="text-[#FF0303] font-itim hover:text-[#17FF03] text-[40px]">Up</h1>
                </div>
            </a>
            <ul class="text-white font-poppins md:flex md:items-center z-[1] md:top-100 md:z-auto md:static absolute bg-grey md:bg-transparent w-full left-0 pb-5 md:w-auto md:py-0 py-0 md:pl-0 pl-7 md:opacity-100 opacity-0 top-[-400px] transition-all ease-in duration-500">
                <li class="mx-4 my-6 md:my-0">
                    <a href="#" class="text-2xl hover:text-primary hover:underline ">Skill</a>
                </li>
                <li class="mx-4 my-6 md:my-0">
                    <a href="#about" class="text-2xl hover:text-primary hover:underline ">Project</a>
                </li>
            </ul>
        </div>
    </nav>
</section>






<section class="pt-20 font-poppins text-white">
    <div class="container border border-gray-600 rounded-xl bg-transparent backdrop-blur-lg">
        <div class="row">
            <div class="md-col-6">
                <a href="<?php echo e(route('posts.create')); ?>"><button type="button" class="border-4 border-str-btn rounded-xl bg-btn-contact my-6 py-3 px-8 text-white font-poppins transform transition hover:scale-105 duration-300 ease-in-out ">
                    Tambah Skill
                </button></a>
            </div>
        </div>
        <div class="row text-[20px]">
            <h1>SKILL YANG TELAH DIMILIKI</h1>
            <div class="md-col-6">
            <div class="border rounded mt-3">
                    <div class="">
                        <table class=" table-fixed bg-gray-500 w-full">
                            <thead>
                              <tr>
                                <th class="border-x-2 border-slate-400">NAMA</th>
                                <th class="border-x-2 border-slate-400">GAMBAR</th>
                                <th class="border-x-2 border-slate-400" style="width: 15%">AKSI</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="p-5 border-2 border-slate-400"><?php echo e($post->nama); ?></td>
                                    <td class="border-2 border-slate-400 text-center">
                                        <img class="mx-auto py-2" src="<?php echo e(asset('storage/posts/'.$post->image)); ?>" class="rounded" style="width: 150px">
                                    </td>
                                    <td class="text-center justify-center border-2 border-slate-400">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                                            <!-- <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="m-2"><i class="fa fa-eye"></i></a> -->
                                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="m-2"><i class="fa fa-pencil-alt"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="m-2"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  <!-- <div class="alert alert-danger">
                                      Data Post belum Tersedia.
                                  </div> -->
                              <?php endif; ?>
                            </tbody>
                          </table>  
                          <?php echo e($posts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- 
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-md btn-success mb-3">TAMBAH POST</a>
                        <table class="table table-bordered">
                            <thead>
                              <tr>
                                <th scope="col">GAMBAR</th>
                                <th scope="col">JUDUL</th>
                                <th scope="col">CONTENT</th>
                                <th style="width: 15%">AKSI</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center">
                                        <img src="<?php echo e(asset('storage/posts/'.$post->image)); ?>" class="rounded" style="width: 150px">
                                    </td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo $post->content; ?></td>
                                    <td class="text-center">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-sm btn-dark"><i class="fa fa-eye"></i></a>
                                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-pencil-alt"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  <div class="alert alert-danger">
                                      Data Post belum Tersedia.
                                  </div>
                              <?php endif; ?>
                            </tbody>
                          </table>  
                          <?php echo e($posts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
     -->

    <script>
        //message with toastr
        <?php if(session()->has('success')): ?>
        
            toastr.success('<?php echo e(session('success')); ?>', 'BERHASIL!'); 

        <?php elseif(session()->has('error')): ?>

            toastr.error('<?php echo e(session('error')); ?>', 'GAGAL!'); 
            
        <?php endif; ?>
    </script>

</body>
</html><?php /**PATH C:\laragon\www\crud-portolk\resources\views/posts/index.blade.php ENDPATH**/ ?>